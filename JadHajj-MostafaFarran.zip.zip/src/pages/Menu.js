import React from 'react'

const menu = () => {
  return (
    <div>
        <h1> Menu </h1>
    </div>
  )
}

export default menu
